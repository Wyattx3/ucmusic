# -*- coding: utf-8 -*-
from utils.client import BotPool

pool = BotPool()

pool.setup()
